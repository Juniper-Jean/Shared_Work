# ** Title, description

rm(list = ls())
graphics.off()

iter <- as.numeric(Sys.getenv("PBS_ARRAY_INDEX"))
#iter <- 1 # Test

speciation_rate <- 0.003617

# We will run 100 simulations.
if((iter > 0)&&(iter <= 25)){ # if(0 < iter <= 25)
  size <- 500
}

if((iter > 25)&&(iter <= 50)){
  size <- 1000
}

if((iter > 50)&&(iter <= 75)){
  size <- 2500
}

if((iter > 75)&&(iter <= 100)){
  size <- 5000
}

wall_time <- 11.5*60 # 11.5 hours = 11.5*60 minutes
#wall_time <- 10

rand_seed <- iter

interval_rich <- 1

interval_oct <- size/10

burn_in_time <- size*8


## Simulation
cluster_run <- function(speciation_rate, size, wall_time, rand_seed, interval_rich, interval_oct, burn_in_time){
  
  ## Set the seed for random number generation.
  set.seed(rand_seed)
  
  ## Set up a timer.
  start_time <- proc.time()[[3]]
  # The start time is the current elapsed time.
  # (View 'proc.time()''s output. '[[3]]' extracts the 'elapsed' time value.)
  
  finish_time <- start_time + wall_time*60
  # 'proc.time()' is in seconds, whereas 'wall_time' is in minutes.
  
  ## Generate an initial state for the simulation community, with the maximum number of species for the community size.
  state <- initialise_max(size)
  
  ## Set a generation count.
  generation_n <- 0
  
  
  time_series <- vector('numeric')
  # Make an empty vector, which we will fill with numeric values.
  
  octaves_list <- list()
  # Make an empty list.
  
  while(proc.time()[[3]] < finish_time){
    # Run the simulation for a time given by 'wall_time'.
    # Note 'while' is a loop. It will perform the code below once, then keep repeating it, until the above condition is not met.
    
    ## Run the neutral model for one generation. One generation involves a birth or death for every individual. If size is 100, one generation is 50 time steps.
    for(i in 0:(size/2)){
      state <- neutral_step_speciation(state, speciation_rate)
      # Overwrite the community state each iteration.
    }
    
    ## During the burn in, record species richness every 'interval_rich' generations.
    if((generation_n <= burn_in_time)&&(generation_n %% interval_rich == 0)){
      time_series <- c(time_series, species_richness(state))
    }
    
    ## For the whole simulation, record species abundance as octaves every 'interval_oct' generations.
    if(generation_n %% interval_oct == 0){
      octaves_list[[length(octaves_list) + 1]] <- octaves(species_abundance(state))
      # Append the octaves vector to the end of the list.
    }
    
    ## Update the generation counter.
    generation_n <- generation_n + 1
    
    ## The 'while' loop will repeat this code for the next generation.
  }
  
  ## The time consumed by the simulation.
  time_taken <- finish_time - start_time
  
  ## Only used to check outputs when testing function:
  # print('Times series of species richness:')
  # print(time_series)
  # # print('Species abundance octaves:')
  # # print(octaves_list)
  # print('Community state at the end:')
  # print(state)
  # print('Time taken:')
  # print(time_taken)
  # print('Number of generations:')
  # print(generation_n)
  
  ## Save results to an Rdata file.
  save(time_series, # Time series of species richness, recorded during the burn in.
       octaves_list, # List of species abundance octaves.
       state, # Community state at the end of the simlation.
       time_taken,
       speciation_rate, # The 7 input parameters:
       size,
       wall_time,
       rand_seed,
       interval_rich,
       interval_oct,
       burn_in_time,
       file = paste("cluster_results_",rand_seed,".Rdata",sep = ""))
}


####################
# Functions called by 'cluster_run'
####################
## Generates an intial state for the simulation community, with the maximum number of species.
initialise_max <- function(size){
  seq(size)
}


## Performs one step of a neutral model with speciation.
## Replaces a dead individual with a new species with probability v.
neutral_step_speciation <- function(community, v){
  x <- runif(1, 0, 1)
  individuals <- choose_two(length(community))
  if (x >= v){
    community[individuals[1]] <- community[individuals[2]]
  } else{
    community[individuals[1]] <- max(community) + 1
  }
  return(community)
}


## Randomly chooses two different individuals from a community.
choose_two <- function(x){
  sample(x, 2, replace = F)
}


## Measures the species richness of (number of unique items in) a community.
species_richness <- function(community){
  length(unique(community))
}


## Bins species abundances into octave classes.
octaves <- function(abundances){
  bins <- floor(log2(abundances)) + 1
  max_bin <- max(bins)
  tally <- seq(0, 0, length.out = max_bin)
  for (i in bins){
    tally[i] <- tally[i] + 1
  }
  return(tally)
}


## Returns abundance of each species in a community.
species_abundance <- function(community){
  x <- as.vector(table(community))
  sort(x, decreasing = T)
}


###############
# Run 'cluster_run'.
###############
cluster_run(speciation_rate, size, wall_time, rand_seed, interval_rich, interval_oct, burn_in_time)